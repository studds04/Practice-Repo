package com.mypackage.controller;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mypackage.dto.UserDto;

@Controller
public class FormController {

	@RequestMapping(path = "/wo", method = RequestMethod.GET)
	@ResponseBody
	public String work() {
		return "working";
	}

	@RequestMapping(path = "/", method = RequestMethod.GET)
	public String register(@ModelAttribute UserDto userDto) {
		
		return "Registration-page";
	}

	@RequestMapping(path = "/display", method = RequestMethod.GET)
	public String display(@Valid @ModelAttribute UserDto userDto, BindingResult result) {

		if (result.hasErrors()) {
			System.out.println("Error occurs");

			List<ObjectError> allErrors = result.getAllErrors();
			for (ObjectError objectError : allErrors) {
				System.out.println(objectError);

				System.out.println("\n\n" + result.getFieldError());

			}

			String[] suppressedFields = result.getSuppressedFields();
			System.out.println("******************** " + suppressedFields.length);
			for (String string : suppressedFields) {
				System.out.println(suppressedFields);
			}

			return "Registration-page";
		}

		return "display-page";
	}

}
